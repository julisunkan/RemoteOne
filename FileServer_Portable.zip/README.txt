WiFi File Server - Portable Version
===================================

This is a portable version of the WiFi File Server that works on any computer with Python installed.

Requirements:
- Python 3.7 or newer
- Internet connection (for first-time setup to install dependencies)

How to Run:

Windows:
1. Double-click "start_fileserver.bat"
2. Wait for dependencies to install (first time only)
3. The server will start and show you the access URL and password

Linux/Mac:
1. Open terminal in this folder
2. Run: ./start_fileserver.sh
3. Wait for dependencies to install (first time only)  
4. The server will start and show you the access URL and password

Features:
- Secure password-protected access
- File upload and download
- Works on local network (WiFi sharing)
- QR code for easy mobile access
- Support for all file types
- Progressive Web App (installable on mobile)

Troubleshooting:
- Make sure Python is installed: python --version
- If script fails, try: python main.py
- For Windows: python -m pip install -r requirements.txt
- For Linux/Mac: python3 -m pip install -r requirements.txt

The server will be accessible at: http://[your-ip]:5000
Password will be shown when the server starts.
