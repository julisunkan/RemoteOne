#!/bin/bash
echo "Starting File Server..."
echo
echo "Installing Python dependencies..."
python3 -m pip install -r requirements.txt --quiet
echo
echo "Starting server..."
python3 main.py
